search
======

An Open Source Search Engine
Completely written in PHP and uses the following PHP libraries :

1) PHPCrawler (customized)

2) SimpleHTMLDom

Called by the name "Web Search" (WS) and it has its own crawler named Dingo! which is also written in PHP. Crawler runs every minute and indexes upto 100 pages each minute.
That's 6000 pages every hour !

See Stats : http://search.subinsb.com/about/stats.php
