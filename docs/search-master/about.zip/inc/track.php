<?php 
if(HOST=="http://search.subinsb.com"){
?>
 <script type="text/javascript">
 var sc_project=9729182;
 var sc_invisible=1;
 var sc_security="f7e9a3d1";
 var scJsHost = (("https:" == document.location.protocol) ? "https://secure." : "http://www.");
 slash = "/";
 document.write("<sc"+"ript type='text/javascript' src='" + scJsHost+ "statcounter.com/counter/counter.js'><"+slash+"script>");
 </script>
 <noscript>
  <div class="statcounter" style="display:none;">
   <img class="statcounter" src="http://c.statcounter.com/9729182/0/f7e9a3d1/1/" alt="hits counter" />
  </div>
 </noscript>
<?php 
}
?>
